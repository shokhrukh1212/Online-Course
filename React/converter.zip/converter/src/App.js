import Converter from "./Converter";

function App() {
  return <Converter />;
}

export default App;
